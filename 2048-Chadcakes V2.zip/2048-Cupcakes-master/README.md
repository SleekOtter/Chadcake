# 2048 Cupcakes
[2048 Cupcakes](https://henry7720.github.io/2048-cupcakes/) is a [2048](https://github.com/gabrielecirulli/2048/)-based game that uses almost exactly the same code, yet, uses cupcake images in place of the numbers.
I figured that if I showed this to people, they might be able to easily make their own clones!

**Here's a hint (for making your own):** go to `style/main.css` at line [`436`](style/main.css#L436): notice how there's a `background` property? Enjoy!
